/*
*Joshua Hunter
*cs210
*grocery tracking program
*/
#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

int main() {
	map<string, int> item_freq;
	ifstream input_file("CS210_Project_Three_Input_File.txt");// input file
	ofstream output_file("frequency.dat");// output file

	//read items from input and store freq
	string item;
	while (input_file >> item) {
		++item_freq[item];
	}
	//write into outputfile for backup
	for (auto i : item_freq) {
		output_file << i.first << ' ' << i.second << endl;
	}
	// display menu and selection
	int selection;
	do {
		cout << "Menu Selections:" << endl;
		cout << "1. Enter an item for specific frequency " << endl;
		cout << "2. A list that represents the frequency of all items" << endl;
		cout << "3. A list that represents the frequency of all items as a histogram" << endl;
		cout << "4. Exit" << endl;
		cout << "Enter your selection: ";
		cin >> selection;
		switch (selection) {
		case 1: {
			string specific_item;
			cout << "Enter specific item for frequency of: ";
			cin >> specific_item;
			cout << specific_item << " found " << item_freq[specific_item] << "times." << endl;
			break;
		}
		case 2: {
			cout << "Item Frequency" << endl;
			for (auto i : item_freq) {
				cout << i.first << ' ' << i.second << endl;
			}
			break;
		}
		case 3: {
			cout << "Item Histogram" << endl;
			for (auto i : item_freq) {
				cout << i.first << " ";
				for (int j = 0; j < i.second; ++j) {
					cout << "*";
				}
				cout << endl;
			}
			break;
		}
		case 4: {


			break;
		}
		default: {
			cout << "Selection is invalid. Try again." << endl;
			break;
		}
		}//switch
	} while (selection != 4);

		return 0;
	}
